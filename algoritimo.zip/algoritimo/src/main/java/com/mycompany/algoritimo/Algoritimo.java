/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.algoritimo;

/**
 *
 * @author Rafael
 */
public class Algoritimo {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
